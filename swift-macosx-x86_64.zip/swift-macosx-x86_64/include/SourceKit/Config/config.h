/* This generated file is for internal use. Do not include it from headers. */

#ifndef SOURCEKIT_CONFIG_H
#define SOURCEKIT_CONFIG_H

/* Define to 1 if you have the 'dispatch_block_create' function in <dispatch/dispatch.h> */
#define HAVE_DISPATCH_BLOCK_CREATE 1

#endif
