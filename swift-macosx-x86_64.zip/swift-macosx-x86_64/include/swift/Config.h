// This file is processed by CMake.
// See https://cmake.org/cmake/help/v3.0/command/configure_file.html.

#ifndef SWIFT_CONFIG_H
#define SWIFT_CONFIG_H

#define SWIFT_HAVE_WORKING_STD_REGEX 1

#define HAVE_UNICODE_LIBEDIT 1

#define HAVE_WAIT4 1

#define HAVE_PROC_PID_RUSAGE 1

#endif // SWIFT_CONFIG_H
