void
#if defined(_WIN32)
__declspec(dllexport)
#endif
_Block_release(void) { }
